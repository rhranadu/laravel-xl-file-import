<div>
    <h1>Import data</h1>
</div>
<form action="/users/import" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
    <div class="from group">
        <input type="file" name="file"/>
        <button type="submit" class="btn btn-primary">Import</button>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\laravel\shikhun\resources\views/users/import.blade.php ENDPATH**/ ?>