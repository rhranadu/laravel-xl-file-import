<?php

namespace App\Imports;
use App\Models\ExtSupervisor;
use \App\Models\User;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Concerns\ToModel;

class UsersImport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new ExtSupervisor([
            'exam_date' => $row[0],
            'exam_roll'=>$row[1],
            'application_category'=>$row[2],
            'board_member_name'=>$row[3],
            'interview_board_name'=>$row[4],
            'previous_certificate_category'=>$row[5],
            'previous_certificate_number'=>$row[6],
            'applicant_full_name'=>$row[7],
            'father_name'=>$row[8],
            'phone_number'=>$row[9],
            'email'=>$row[10],
            'date_of_birth'=>$row[11],
            'nid_number'=>$row[12],
            'village'=>$row[13],
            'postcode'=>$row[14],
            'upazilla'=>$row[15],
            'district'=>$row[16],
            'division'=>$row[17],
            'degree'=>$row[18],
            'subject'=>$row[19],
            'board'=>$row[20],
            'academic_result'=>$row[21],
            'passing_year'=>$row[22],
            'company'=>$row[23],
            'designation'=>$row[24],
            'issu_date'=>$row[25],
            'certificate_number'=>$row[26],
            'expiry_date'=>$row[27],
        ]);
    }
}
