<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateExtSupervisorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ext_supervisors', function (Blueprint $table) {
            $table->id();
            $table->string('exam_date')->nullable();
            $table->string('exam_roll')->nullable();
            $table->string('application_category')->nullable();
            $table->string('board_member_name')->nullable();
            $table->string('interview_board_name')->nullable();
            $table->string('previous_certificate_category')->nullable();
            $table->string('previous_certificate_number')->nullable();
            $table->string('applicant_full_name')->nullable();
            $table->string('father_name')->nullable();
            $table->string('phone_number')->nullable();
            $table->string('email')->nullable();
            $table->string('date_of_birth')->nullable();
            $table->string('nid_number')->nullable();
            $table->string('village')->nullable();
            $table->string('postcode')->nullable();
            $table->string('upazilla')->nullable();
            $table->string('district')->nullable();
            $table->string('division')->nullable();
            $table->string('degree')->nullable();
            $table->string('subject')->nullable();
            $table->string('board')->nullable();
            $table->string('academic_result')->nullable();
            $table->string('passing_year')->nullable();
            $table->string('company')->nullable();
            $table->string('designation')->nullable();
            $table->string('total_job_duration')->nullable();

            $table->string('issu_date')->nullable();
            $table->string('certificate_number')->nullable();
            $table->string('expiry_date')->nullable();
            $table->string('status')->default('pending');
            $table->string('level_on_approval')->nullable();
            $table->string('secretary_approval')->nullable();
            $table->string('chairman_approval')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ext_supervisors');
    }
}
